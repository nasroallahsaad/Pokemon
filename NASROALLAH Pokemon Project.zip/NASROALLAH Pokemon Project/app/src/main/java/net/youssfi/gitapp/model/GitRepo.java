package net.youssfi.gitapp.model;

public class GitRepo {
    public int id;
    public String name;
    public int size;
    public String language;
}
